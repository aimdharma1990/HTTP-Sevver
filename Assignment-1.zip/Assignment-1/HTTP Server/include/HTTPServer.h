#ifndef _SELECT_H_
#define _SELECT_H_

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <winsock2.h>
#include <vector>
#include <string>
#include <windows.h>
#include <Shlwapi.h>
#include <string>
#include <fstream>
#include <streambuf>

//Disable deprecation warnings

#pragma warning(disable: 4996)

//Buffer Length 

#define STD_BUFF 1024
#define MAX_BUFF STD_BUFF * STD_BUFF

class CClientContext  //To store and manage client related information
{
private:

     int               m_nTotalBytes;
     int               m_nSentBytes;
     SOCKET            m_Socket;  //accepted socket
     char              m_szBuffer[MAX_BUFF];
     CClientContext   *m_pNext; //this will be a singly linked list

public:

     //Get/Set calls
     void SetTotalBytes(int n)
     {
          m_nTotalBytes = n;
     }

     int GetTotalBytes()
     {
          return m_nTotalBytes;
     }

     void SetSentBytes(int n)
     {
          m_nSentBytes = n;
     }

     void IncrSentBytes(int n)
     {
          m_nSentBytes += n;
     }

     int GetSentBytes()
     {
          return m_nSentBytes;
     }

     void SetSocket(SOCKET s)
     {
          m_Socket = s;
     }

     SOCKET GetSocket()
     {
          return m_Socket;
     }

     void SetBuffer(char *szBuffer, int len)
     {

		 memset(m_szBuffer, 0, sizeof(m_szBuffer));
		 _sntprintf(m_szBuffer, len, "%s", szBuffer);
		  m_nTotalBytes = len;
		  m_nSentBytes = 0;
     }

     void GetBuffer(char *szBuffer)
     {
          strcpy(szBuffer, m_szBuffer);
     }

     char* GetBuffer()
     {
          return m_szBuffer;
     }

     void ZeroBuffer()
     {
          ZeroMemory(m_szBuffer, MAX_BUFF);
     }

     CClientContext* GetNext()
     {
          return m_pNext;
     }

     void SetNext(CClientContext *pNext)
     {
          m_pNext = pNext;
     }

     //Constructor
     CClientContext()
     {
          m_Socket =  SOCKET_ERROR;
          ZeroMemory(m_szBuffer, MAX_BUFF);
          m_nTotalBytes = 0;
          m_nSentBytes = 0;
          m_pNext = NULL;
     }

     //destructor
     ~CClientContext()
     {
          closesocket(m_Socket);
     }
};


//Object creation
CClientContext    *g_pClientContextHead = NULL;
fd_set g_ReadSet, g_WriteSet, g_ExceptSet;

//Function Declaration

void AddClientContextToList(CClientContext *pClientContext);
void AcceptConnections(SOCKET ListenSocket);
void InitSets(SOCKET ListenSocket);

int GetSocketSpecificError(SOCKET Socket);
int ParseRequest(CClientContext*);

CClientContext* DeleteClientContext(CClientContext *pClientContext);
CClientContext* GetClientContextHead();

#endif