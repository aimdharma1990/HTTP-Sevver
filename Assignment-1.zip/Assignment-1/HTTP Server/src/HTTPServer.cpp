#include "stdafx.h"
#include "HTTPServer.h"

//#define DEBUG_PROGRAM  //UnComment to print more debug logs

using namespace std;

char g_chLocalDir[STD_BUFF] = "";

int main(int argc, char *argv[])
{
	 //Variable section
	 int    nResult = -1;
	 int    nPortNo = 80;
	 SOCKET ListenSocket;
	 struct sockaddr_in ServerAddress;

     //Validate the input
     if (argc < 2) 
     {
          printf("\nHTTP SERVER Usage .. HTTPServer.exe <port>\n");
		  getch();
          return -1;
     }

	 
	 #ifdef DEBUG_PROGRAM
	 _tprintf(_T("HTTP Server port --%d"), argv[1]);
	 #endif //DEBUG_PROGRAM

     // Initialize Winsock
     WSADATA wsaData;

     nResult = WSAStartup(MAKEWORD(2,2), &wsaData);

     if ( nResult != NO_ERROR )
     {
          printf("\nError occurred while executing WSAStartup() Init");
          return 1; //error
     }
     else
     {
		 #ifdef DEBUG_PROGRAM
		 printf("\nWSAStartup() successful.");
		 #endif //DEBUG_PROGRAM          
     }


	 
	 //Getting the Current Directory
	 GetCurrentDirectory(STD_BUFF, g_chLocalDir);

	 #ifdef DEBUG_PROGRAM
	 _tprintf(_T("Current Directory of the Server %s"), g_chLocalDir);
     #endif //DEBUG_PROGRAM

     //Create a socket
     ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

     if (INVALID_SOCKET == ListenSocket) 
     {
          printf("\nError occurred while opening socket: %ld.\n", WSAGetLastError());
		  WSACleanup();
          return -1;
     }
     else
     {
          printf("\nHTTP Server Starting...");
     }

	 #ifdef DEBUG_PROGRAM
	 printf("\n Listen Socket created successful.");
	 #endif //DEBUG_PROGRAM

     ZeroMemory((char *)&ServerAddress, sizeof(ServerAddress));
	 nPortNo = atoi(argv[1]);
     
     ServerAddress.sin_family = AF_INET;
     ServerAddress.sin_addr.s_addr = INADDR_ANY; //WinSock will supply address
     ServerAddress.sin_port = htons(nPortNo);    //comes from commandline

     //Assign local address and port number
     if (SOCKET_ERROR == bind(ListenSocket, (struct sockaddr *) &ServerAddress, sizeof(ServerAddress))) 
     {
          closesocket(ListenSocket);
		  printf("\nError occurred while binding to the Port -%d. Error -%d\n", nPortNo, GetLastError());
          WSACleanup();
		  return -1;
     }
     else
     {
		  #ifdef DEBUG_PROGRAM
	      printf("\n HTTP Server binded successfully with %d Port.", nPortNo);
	      #endif //DEBUG_PROGRAM
		  Sleep(10);
          printf("...");
     }

	 //Listen socket for the server
     if ( listen(ListenSocket,SOMAXCONN) == SOCKET_ERROR )
     {
          closesocket(ListenSocket);
          printf("\nHTTP Server Error occurred while listening. Error Code -%d\n", GetLastError());
          WSACleanup();
		  return -1;
     }
     else
     {
		  Sleep(10);
		  #ifdef DEBUG_PROGRAM
	      printf("\n HTTP Server listen successfully with %d Port.", nPortNo);
	      #endif //DEBUG_PROGRAM
          printf("...");
     }

     /**
	  * HTTP Server should cabable of handling the mutiple requeste from the mutiple web clients.
	  * So instead of creating a single socket function we can go ahead with the select function to handle 
	  * multiple request
	  */
	 
     AcceptConnections(ListenSocket);

	  #ifdef DEBUG_PROGRAM
      printf("\n HTTP Server is completed successfully with %d Port.", nPortNo);
      #endif //DEBUG_PROGRAM

      //Our job is done. Lets do house keeping our self.
      closesocket(ListenSocket);

      //Cleanup Winsock
      WSACleanup();

     return 0; 
}


/****************************************************************************************
/* Function Name : InitSets
/* Input         : Socket which is created already
/* Return        : void
/* Usage         : This function used to init the read and write set for the select
****************************************************************************************/


void InitSets(SOCKET ListenSocket) 
{
     //Initialize
     FD_ZERO(&g_ReadSet);
     FD_ZERO(&g_WriteSet);
     FD_ZERO(&g_ExceptSet);

     //Assign the ListenSocket to Sets
     FD_SET(ListenSocket, &g_ReadSet);
     FD_SET(ListenSocket, &g_ExceptSet);

     //Iterate the client context list and assign the sockets to Sets
     CClientContext   *pClientContext  = GetClientContextHead();

     while(pClientContext)
     {
          if(pClientContext->GetSentBytes() < pClientContext->GetTotalBytes())
          {
               //We have data to send
               FD_SET(pClientContext->GetSocket(), &g_WriteSet);
          }
          else
          {
               //We can read on this socket
               FD_SET(pClientContext->GetSocket(), &g_ReadSet);
          }

          //Add it to Exception Set
          FD_SET(pClientContext->GetSocket(), &g_ExceptSet); 

          //Move to next node on the list
          pClientContext = pClientContext->GetNext();
     }
}
/****************************************************************************************
/* Function Name : AcceptConnections
/* Input         : Listen socket which is created already
/* Return        : void
/* Usage         : This is heart of the HTTP server which will recive the request from the client 
/*                 and process it in while loop
****************************************************************************************/

void AcceptConnections(SOCKET ListenSocket)
{
	 _tprintf("\nHTTP Server started\n");
     while (true)
	 {
          InitSets(ListenSocket);

          if (select(0, &g_ReadSet, &g_WriteSet, &g_ExceptSet, 0) > 0) 
          {
               if (FD_ISSET(ListenSocket, &g_ReadSet)) 
               {
                    sockaddr_in ClientAddress;

                    int nClientLength = sizeof(ClientAddress);

                    //Accept remote connection attempt from the client
                    SOCKET Socket = accept(ListenSocket, (sockaddr*)&ClientAddress, &nClientLength);

                    if (INVALID_SOCKET == Socket)
                    {
						_tprintf(_T("\nError occurred while accepting socket: %ld."), GetSocketSpecificError(ListenSocket));
                    }

					#ifdef DEBUG_PROGRAM
					_tprintf(_T("\HTTP Client connected from: %S"), inet_ntoa(ClientAddress.sin_addr)); 
					#endif //DEBUG_PROGRAM
                   
                    //Making it a non blocking socket
                    u_long nNoBlock = 1;
                    ioctlsocket(Socket, FIONBIO, &nNoBlock);

                    CClientContext   *pClientContext  = new CClientContext;
                    pClientContext->SetSocket(Socket);

                    //Add the client context to the list
                    AddClientContextToList(pClientContext);
               }

               if (FD_ISSET(ListenSocket, &g_ExceptSet)) 
               {
				   #ifdef DEBUG_PROGRAM
				   _tprintf(_T("\nError occurred while accepting socket: %ld."), GetSocketSpecificError(ListenSocket));
				   #endif //DEBUG_PROGRAM                    
                   continue;
               }

               //Iterate the client context list to see if any of the socket there has changed its state
               CClientContext   *pClientContext  = GetClientContextHead();

               while (pClientContext)
               {
                    //Check in Read Set
                    if (FD_ISSET(pClientContext->GetSocket(), &g_ReadSet))
                    {
                         int nBytes = recv(pClientContext->GetSocket(), pClientContext->GetBuffer(), MAX_BUFF, 0);
                         if (( nBytes == 0 ) || (SOCKET_ERROR == nBytes))
                         {                       
							  #ifdef DEBUG_PROGRAM
							  _tprintf(_T("\n Socket closed or no data present to recv");
							  #endif //DEBUG_PROGRAM
                              pClientContext = DeleteClientContext(pClientContext);
                              continue;
                         }

						 //Here is the logic to make this as the http server. 
						 ParseRequest(pClientContext);

                         pClientContext->SetSentBytes(0);
						 #ifdef DEBUG_PROGRAM
						 printf("\nThe following message was received: %s", pClientContext->GetBuffer());
						 #endif
                    }

                    if (FD_ISSET(pClientContext->GetSocket(), &g_WriteSet))
                    {
                         int nBytes = 0;

                         if ((pClientContext->GetTotalBytes() - pClientContext->GetSentBytes()) > 0 )
                         {
							 //Sending the response to the client. 
							 nBytes = send(pClientContext->GetSocket(), (pClientContext->GetBuffer() + pClientContext->GetSentBytes()), (pClientContext->GetTotalBytes() - pClientContext->GetSentBytes()), 0);

                              if (SOCKET_ERROR == nBytes)
                              {
								   #ifdef DEBUG_PROGRAM
								  _tprintf(_T("Error occurred while sending on the socket: %d."), GetSocketSpecificError(pClientContext->GetSocket()));
								   #endif
                                   pClientContext = DeleteClientContext(pClientContext);
                                   continue;
                              }
                              if (nBytes == (pClientContext->GetTotalBytes() - pClientContext->GetSentBytes()))
                              {
								  #ifdef DEBUG_PROGRAM
								  _tprintf(_T("Resetting the data buffer"));
								  #endif
                                   //We are done sending the data, reset Buffer Size
                                   pClientContext->SetTotalBytes(0);
                                   pClientContext->SetSentBytes(0);								   
								   shutdown(pClientContext->GetSocket(), SD_BOTH);
                              }
                              else
                              {
                                   pClientContext->IncrSentBytes(nBytes);
                              }			
							  
                         }
                    }

                    //Check in Exception Set
                    if (FD_ISSET(pClientContext->GetSocket(), &g_ExceptSet))
                    {
						 #ifdef DEBUG_PROGRAM
                         printf("\nError occurred on the socket: %d.", GetSocketSpecificError(pClientContext->GetSocket()));
						 #endif
                         pClientContext = DeleteClientContext(pClientContext);
                         continue;
                    }

                    //Move to next node on the list
                    pClientContext = pClientContext->GetNext();
               }//End of while
          }
          else //select
          {
               _tprintf(_T("\nError occurred while executing select(): %ld."), WSAGetLastError());
               return; //Get out of this function
          }
     }
}


/****************************************************************************************
/* Function Name : GetSocketSpecificError
/* Input         : Socket which is created already
/* Return        : Socket error code
/* Usage         : Reading the socket error
****************************************************************************************/

int GetSocketSpecificError(SOCKET Socket)
{
     int nOptionValue;
     int nOptionValueLength = sizeof(nOptionValue);
     getsockopt(Socket, SOL_SOCKET, SO_ERROR, (char*)&nOptionValue, &nOptionValueLength);
	 return nOptionValue;
}

/****************************************************************************************
/* Function Name : GetClientContextHead
/* Input         : void
/* Return        : ContextHead
/* Usage         : Getting the context head
****************************************************************************************/

CClientContext* GetClientContextHead()
{
     return g_pClientContextHead;
}


/****************************************************************************************
/* Function Name : AddClientContextToList
/* Input         : Client context
/* Return        : void
/* Usage         : Adding to the list
****************************************************************************************/

void AddClientContextToList(CClientContext *pClientContext)
{
     //Add the new client context right at the head
     pClientContext->SetNext(g_pClientContextHead);
     g_pClientContextHead = pClientContext;
}

/****************************************************************************************
/* Function Name : DeleteClientContext
/* Input         : Client context which needs to be deleted
/* Return        : Client context after delete
/* Usage         : Delting the Client Context  which is closed or terminated
****************************************************************************************/

CClientContext * DeleteClientContext(CClientContext *pClientContext)
{
     if (pClientContext == g_pClientContextHead) 
     {
          CClientContext *pTemp = g_pClientContextHead;
          g_pClientContextHead = g_pClientContextHead->GetNext();
          delete pTemp;
          return g_pClientContextHead;
     }

     //Iterate the list and delete the appropriate node
     CClientContext *pPrev = g_pClientContextHead;
     CClientContext *pCurr = g_pClientContextHead->GetNext();

     while (pCurr)
     {
          if (pCurr == pClientContext)
          {
               CClientContext *pTemp = pCurr->GetNext();
               pPrev->SetNext(pTemp);
               delete pCurr;
               return pTemp;
          }

          pPrev = pCurr;
          pCurr = pCurr->GetNext();
     }

     return NULL;
}

/****************************************************************************************
/* Function Name : ValidateRequest
/* Input         : Client input data
/* Return        : int (Postion of the HTTP incase failure return -1)
/* Usage         : Validating the HTTP Header
****************************************************************************************/

int ValidateRequest(string *strTempBuffer, CClientContext *pClientData)
{
	int nEndPost = strTempBuffer->find("HTTP/1.1");
	if( nEndPost == std::string::npos )
	{
		char Temp[130000] = "";

		sprintf(Temp, "HTTP/1.0 400 Bad Request\nAccept-Ranges: bytes\nContent-Type: text/html;charset=UTF-8\n\n");
		pClientData->SetBuffer(Temp, strlen(Temp));
	}
	return nEndPost;
}

/****************************************************************************************
/* Function Name : ConstructResponse
/* Input         : GET or POST postion
/* Return        : void
/* Usage         : Constructing the HTTP Response
****************************************************************************************/

void ConstructResponse(int nPosVal, int nEndPost, string &strTempBuffer, CClientContext *pClientData)
{
	char chLocalBuff[STD_BUFF/4]   = "";
	char chFilePath[2*STD_BUFF]    = "";
	char chTemp[STD_BUFF*125]      = "";
	char chBuffer[STD_BUFF]		   = "";

	if( strTempBuffer.substr(nPosVal+5, nEndPost-nPosVal-6).length() < STD_BUFF/4 )
	{
		sprintf(chLocalBuff, strTempBuffer.substr(nPosVal+5, nEndPost-nPosVal-6).c_str());

		//Incase of empty response redirect to the index.html
		if( strlen(chLocalBuff) == 0 ) 
		{
			_tcscpy(chLocalBuff, "index.html");
		}
		
		sprintf(chFilePath, "%s\\%s", g_chLocalDir, chLocalBuff);
		if ( PathFileExists(chFilePath) == TRUE )
		{
			//Reading the data from the file
			std::ifstream t(chFilePath);
			std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());

			if( str.length() <= STD_BUFF * 124 ) 
			{
				sprintf(chTemp, "HTTP/1.1 200 OK \nAccept-Ranges: bytes\nContent-Type: text/html;charset=UTF-8\n\n");
				str.insert(0, chTemp);
				memset(chTemp, 0, sizeof(chTemp));
				sprintf(chTemp, "%s", str.c_str());
				pClientData->SetBuffer(chTemp, str.length());
			}
			else
			{
				memset(chTemp, 0, sizeof(chTemp));
				sprintf(chTemp, "HTTP/1.1 502 Service temporarily overloaded \nAccept-Ranges: bytes\nContent-Type: text/html;charset=UTF-8\n\n");
				pClientData->SetBuffer(chTemp, strlen(chTemp));
			}
		}
		else //Page not found
		{
			//404 Not Found
			memset(chFilePath, 0, sizeof(chFilePath));
			sprintf(chBuffer, "HTTP/1.1 404  Not Found \nAccept-Ranges: bytes\nContent-Type: text/html;charset=UTF-8\n\n");
			sprintf(chFilePath, "%s\\PageNoteFound.html", g_chLocalDir);
			std::ifstream t(chFilePath);
			std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
			str.insert(0, chBuffer);
			memset(chBuffer, 0, sizeof(chBuffer));
			sprintf(chBuffer, "%s", str.c_str());
			pClientData->SetBuffer(chBuffer, strlen(chBuffer));
		}
	}
	else
	{
		strTempBuffer.assign("HTTP/1.1 500 Internal Error\nAccept-Ranges: bytes\nContent-Type: text/html;charset=UTF-8\n\n<html><body><font size = \"5\" color = \"red\">The server encountered an unexpected condition which prevented it from fulfilling the request.</font></body></html>");
		pClientData->SetBuffer((char*)strTempBuffer.c_str(), strTempBuffer.length());
	}
}
/****************************************************************************************
/* Function Name : ParseRequest
/* Input         : Client context which needs to procssed
/* Return        : int
/* Usage         : Prossing the incoming request and set the response object
****************************************************************************************/


int ParseRequest(CClientContext *pClientData)
{
	char chTempBuffer[STD_BUFF*5] = ""; 
	string strTempBuffer          = "";

	//Reading the complete request from the http client and store it for local
	pClientData->GetBuffer(chTempBuffer);
	strTempBuffer.assign(chTempBuffer);

	#ifdef DEBUG_PROGRAM
	_tprintf(_T("Request data from the client-->> %s"), strTempBuffer.c_str());
	#endif //DEBUG_PROGRAM

	//checking the request is GET or POST
	int nStartGETVal  = strTempBuffer.find("GET");
	int nStartPOSTVal = strTempBuffer.find("POST");

	if( nStartGETVal == 0 )//GET Request then processing started
	{
		#ifdef DEBUG_PROGRAM
		_tprintf(_T("GET Request from the HTTP Client"));
		#endif //DEBUG_PROGRAM

		int nEndPost = ValidateRequest(&strTempBuffer, pClientData);

		if(  nEndPost < 0 )
		{
			return -1;
		}
		ConstructResponse(nStartGETVal, nEndPost, strTempBuffer, pClientData);
	}
	else if( nStartPOSTVal == 0 )
	{
		#ifdef DEBUG_PROGRAM
		_tprintf(_T("GET Request from the HTTP Client"));
		#endif //DEBUG_PROGRAM

		int nEndPost = ValidateRequest(&strTempBuffer, pClientData);

		if(  nEndPost < 0 )
		{
			return -1;
		}
		ConstructResponse(nStartPOSTVal,nEndPost, strTempBuffer, pClientData);		
	}
	else
	{
		#ifdef DEBUG_PROGRAM
		_tprintf(_T("Invalid request"));
		#endif //DEBUG_PROGRAM

		strTempBuffer.assign("HTTP/1.1 500 Internal Error\nAccept-Ranges: bytes\nContent-Type: text/html;charset=UTF-8\n\n<html><body><font size = \"5\" color = \"red\">The server encountered an unexpected condition which prevented it from fulfilling the request.</font></body></html>");
		pClientData->SetBuffer((char*)strTempBuffer.c_str(), strTempBuffer.length());
	}
	return 1;	
}

