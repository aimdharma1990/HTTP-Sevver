*************************************
* STPES TO RUN THE HTTP SERVER
*************************************

1. HTPP Server Binary directory will have the binary and web pages to server as the HTTP Server.
2. To run the server start the command prompt and nagviate to the HTTP Server Binary directory and type as "HTTP Server.exe 8080" . 8080 is the HTTP Server port.
   It can be anything which not getting used by standard applications

3. By default http server will redirect to the index.html. But with this sample index.html will redirect to the Login.html. 
4. In login.html will used to perform the post request to the http server and will redirect to the one more sample page called WelcomePage.html.



Note:

The source code is build on windows platform with visual studio 2008 IDE.

